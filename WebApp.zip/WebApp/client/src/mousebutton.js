export const MouseButton = {
  Left: 0,
  Right: 1,
  Middle: 2,
  Foaward: 3,
  Back: 4,
};