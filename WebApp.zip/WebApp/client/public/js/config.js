import {getServers} from "./icesettings.js";

export async function getServerConfig() {
  const protocolEndPoint = location.origin + '/config';
  const createResponse = await fetch(protocolEndPoint);
  return await createResponse.json();
}

export function getRTCConfiguration() {
  let config = {
    sdpSemantics: "unified-plan",
    iceServers: getServers(), // Ensure TURN server is included here
    iceTransportPolicy: "relay", // Force TURN usage (optional)
  };
  return config;
}
