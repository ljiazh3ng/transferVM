import { getServerConfig, getRTCConfiguration } from "../../js/config.js";
import { createDisplayStringArray } from "../../js/stats.js";
import { VideoPlayer } from "../../js/videoplayer.js";
import { RenderStreaming } from "../../module/renderstreaming.js";
import { Signaling, WebSocketSignaling } from "../../module/signaling.js";
import { readServersFromLocalStorage, getServers } from "../../js/icesettings.js";  // ✅ Import ICE settings

///** @type {Element} */
//let playButton;
/** @type {RenderStreaming} */
let renderstreaming;
/** @type {boolean} */
let useWebSocket;

const codecPreferences = document.getElementById('codecPreferences');
const supportsSetCodecPreferences = window.RTCRtpTransceiver &&
  'setCodecPreferences' in window.RTCRtpTransceiver.prototype;
const messageDiv = document.getElementById('message');
messageDiv.style.display = 'none';

const playerDiv = document.getElementById('player');
const lockMouseCheck = document.getElementById('lockMouseCheck');
const videoPlayer = new VideoPlayer();

// --- NEW: Variables for toggle mute button ---
/*let isMuted = true;
let toggleMuteButton;*/

document.addEventListener("DOMContentLoaded", function () {
  setup();
});

window.document.oncontextmenu = function () {
  return false;     // cancel default menu
};

window.addEventListener('resize', function () {
  videoPlayer.resizeVideo();
}, true);

window.addEventListener('beforeunload', async () => {
  if (!renderstreaming)
    return;
  await renderstreaming.stop();
}, true);

async function setup() {
  // ✅ Ensure ICE servers are loaded before connecting
  readServersFromLocalStorage();

  const res = await getServerConfig();
  useWebSocket = res.useWebSocket;
  showWarningIfNeeded(res.startupMode);
  //showCodecSelect();
  //showPlayButton();

  // Create the video player
  videoPlayer.createPlayer(playerDiv, lockMouseCheck);

  // --- NEW: Add toggle mute button after player creation ---
  //showToggleMuteButton();

  setupRenderStreaming();

}


function showWarningIfNeeded(startupMode) {
  const warningDiv = document.getElementById("warning");
  if (startupMode == "private") {
    warningDiv.innerHTML = "<h4>Warning</h4> This sample is not working on Private Mode.";
    warningDiv.hidden = false;
  }
}

//function showPlayButton() {
//  if (!document.getElementById('playButton')) {
//    const elementPlayButton = document.createElement('img');
//    elementPlayButton.id = 'playButton';
//    elementPlayButton.src = '../../images/Play.png';
//    elementPlayButton.alt = 'Start Streaming';
//    playButton = document.getElementById('player').appendChild(elementPlayButton);
//    playButton.addEventListener('click', onClickPlayButton);
//  }
//}

//function onClickPlayButton() {
//  playButton.style.display = 'none';

//  // add video player
//  videoPlayer.createPlayer(playerDiv, lockMouseCheck);

//  // --- NEW: Re-add toggle mute button when starting streaming again ---
//  showToggleMuteButton();

//  setupRenderStreaming();
//}

async function setupRenderStreaming() {
  //codecPreferences.disabled = true;

  const signaling = useWebSocket ? new WebSocketSignaling() : new Signaling();

  // ✅ Load ICE server configuration dynamically
  const config = getRTCConfiguration();
  config.iceServers = getServers();  // ✅ Ensure the ICE servers are retrieved correctly

  console.log("Using ICE Servers:", config.iceServers);  // ✅ Debugging to check ICE server setup

  renderstreaming = new RenderStreaming(signaling, config);
  renderstreaming.onConnect = onConnect;
  renderstreaming.onDisconnect = onDisconnect;
  renderstreaming.onTrackEvent = (data) => videoPlayer.addTrack(data.track);
  //renderstreaming.onGotOffer = setCodecPreferences;

  await renderstreaming.start();
  await renderstreaming.createConnection();
}

function onConnect() {
  const channel = renderstreaming.createDataChannel("input");
  videoPlayer.setupInput(channel);
  showStatsMessage();
}

async function onDisconnect(connectionId) {
  clearStatsMessage();
  messageDiv.style.display = 'block';
  messageDiv.innerText = `Disconnect peer on ${connectionId}.`;

  await renderstreaming.stop();
  renderstreaming = null;
  videoPlayer.deletePlayer();

  // --- NEW: Remove toggle mute button on disconnect ---
  //if (toggleMuteButton) {
  //  toggleMuteButton.remove();
  //  toggleMuteButton = null;
  //}

  if (supportsSetCodecPreferences) {
    codecPreferences.disabled = false;
  }
 // showPlayButton();
}

// --- NEW: Toggle Mute Button (appended to the player, like the play button) ---
/*function showToggleMuteButton() {
  if (!document.getElementById('toggleMuteButton')) {
    const elementToggleMute = document.createElement('img');
    elementToggleMute.id = 'toggleMuteButton';
    elementToggleMute.src = '../../images/Mute.png';
    elementToggleMute.alt = 'Toggle Mute/Unmute';
    elementToggleMute.style.cursor = 'pointer';

    // Position the button in the top right corner of the player container
    elementToggleMute.style.position = 'absolute';
    elementToggleMute.style.top = '10px';    // adjust as needed
    elementToggleMute.style.right = '10px';   // adjust as needed

    // Optional: specify dimensions for the button image
    elementToggleMute.style.width = '30px';
    elementToggleMute.style.height = '30px';

    // Append just like the play button is appended to the "player" element
    toggleMuteButton = document.getElementById('player').appendChild(elementToggleMute);
    toggleMuteButton.addEventListener('click', onClickToggleMuteButton);
  }
}*/

/*function onClickToggleMuteButton() {
  // Toggle the mute state
  isMuted = !isMuted;
  // Find the video element within the player (assuming there is one)
  const video = playerDiv.querySelector('video');
  if (video) {
    video.muted = isMuted;
    console.log(video.muted);
  }
  // Update the button image based on the current mute state
  toggleMuteButton.src = isMuted ? '../../images/Mute.png' : '../../images/Unmute.png';
}*/

/** @type {RTCStatsReport} */
let lastStats;
/** @type {number} */
let intervalId;

function showStatsMessage() {
  intervalId = setInterval(async () => {
    if (renderstreaming == null) {
      return;
    }

    const stats = await renderstreaming.getStats();
    if (stats == null) {
      return;
    }

    const array = createDisplayStringArray(stats, lastStats);
    if (array.length) {
      messageDiv.style.display = 'block';
      messageDiv.innerHTML = array.join('<br>');
    }
    lastStats = stats;
  }, 1000);
}

function clearStatsMessage() {
  if (intervalId) {
    clearInterval(intervalId);
  }
  lastStats = null;
  intervalId = null;
  messageDiv.style.display = 'none';
  messageDiv.innerHTML = '';
}
